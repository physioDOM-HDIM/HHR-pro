% CHANGELOG
% Fabrice Le Coz
% October 2014

__0.3.0__

  - adds a new attribute "autoRender" ( true by default )
  - removes the obsolete "list" attribut
  - allow to pass a list object to the render method

__0.2.0__ ( 2014-11-17)

Update to polymer 0.5.x

__0.1.2 (2014-11-06)__

Due to some trouble on IE, wait the domReady event before requesting the web service

__0.1.1 (2014-10-31)__

send a "tsante-draw" event when the template has been rendered

FIX event "tsante-error" fired when the received data are not in json format

__0.1.0 ( 2014-10-29 )__

Update to polymer 0.4.2

tested on 

| OS            | browser    | status
|---------------|------------|---------
| OSX 10.10     | Chrome 40  | OK
|               | FF 34      | OK
|               | Safari 8   | NOK
| Win7          | IE10       | OK
| IOS8.1        | Safari     | NOK
| IOS7.1        | Safari     | OK
| Android 4.4.4 | Chrome     | OK 


> __Nota :__ For Safari 8, this was an [issue of polymer](https://github.com/Polymer/docs/issues/612). Should be fixed on next release.

> __Nota 2 :__ On IOS7.1 the component works but need some enhancements.
