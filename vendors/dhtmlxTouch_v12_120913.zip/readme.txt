DHTMLX Touch 1.2

Terms of usage
-------------------
The DHTMLX Touch library v.1.2 is distributed for FREE under both GNU GPL and Commercial License. 
You can use it in your open source or commercial apps at no charge.


Technical Support
-------------------
The official technical support for DHTMLX Touch is provided on the paid basis. To learn about prices or how buy the support,
please contact us at sales@dhtmlx.com

For community support visit DHTMLX Touch forum: http://forum.dhtmlx.com/viewforum.php?f=22


Documentation & Samples
-------------------
Besides documentation included in this package you can use online version: http://docs.dhtmlx.com/touch/
Techical samples included in this package (/samples/technical) can help you to implement some functionality which you had difficalties with


Visual Designer
-------------------
Use online DHTMLX Touch designer (http://www.dhtmlx.com/touch/designer/) to build the interface, then get the code and continue implementing interaction between components.
To get desktop version of the designer, please contact us on sales@dhtmlx.com



(c) Dinamenta, UAB