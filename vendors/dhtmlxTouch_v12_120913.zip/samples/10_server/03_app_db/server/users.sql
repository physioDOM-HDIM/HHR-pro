DROP TABLE IF EXISTS "tblusers";
CREATE TABLE "tblusers" ("id" INTEGER PRIMARY KEY  NOT NULL , "name" VARCHAR(60), age VARCHAR(3), "country" VARCHAR(60), "city" VARCHAR(60), "gender" VARCHAR(6), "phone" VARCHAR(60), "email" VARCHAR(60));
