% component : tsante-listpager
% Fabrice Le Coz
% Sept 2014

# tsante-listpager

the component use [tsante-pager](http://git.telecomsante.com/components/tsante-pager) to render the pager component

## Brief description

This component help to request lists from our REST services, and display the result.

In Telecom Sante REST services, GET requests usually respond with a list in JSON format :

~~~
{ 
    id: "/List",
    "type":"object",
    "properties": {
        "nb": { type:"integer", required:true },
        "pg": { type:"integer", required: true },
        "offset": { type:"integer", required: true },
        "items": { type:"array", item:{ type:"object" } }
    }
}
~~~

example of use :

![](http://git.telecomsante.com/components/tsante-listpager/raw/0.1.0/doc/screenshot.png)

## Using

~~~
<tsante-list url="/api/directory/professionals" pg="1" auto="true" unresolved >
    <template repeat="{{list.items}}">
        <!-- put here the template to render an item -->
    </template>
</tsante-list>
~~~

if you need complex template using polymer expressions, dont't forget to add the attribute is="auto-binding" to the template element.

see :

 - [Polymer Advanced topics](https://www.polymer-project.org/docs/polymer/databinding-advanced.html#autobinding)
 - [&lt;template is="auto-binding"&gt; is=awesome](https://blog.polymer-project.org/howto/2014/09/11/template-is-autobinding/)

~~~
<template id="professional" repeat="{{item in list.items}}" is="auto-binding">
	<div class="item {{ item.active?'':'red'}}">
		<template if="{{ item.organization }}" >
			<div class="name">{{item.name}} (organization) ({{item.active}})</div>
			<div class="role">{{item.role}}</div>
		</template>
		<template if="{{ !item.organization }}">
			<div class="name">{{item.name.family}} {{item.name.given}} ({{item.active}})</div>
			<div class="role">{{item.role}}</div>
		</template>
	</div>
</template>
~~~

## Attributes

**url** url of the service

**pg** page parameter

**offset** offset parameter ( number of items par page )

**auto** if true, the request is done when the html page is ready

**autoRender** true by default, if set to false it's prevent to run the render method after receiving the response. So it's possible to modify the list object before rendering.

## Methods

## Events

__tsante-draw__ : is emitted when the template model has been applied and elements added to the LightDOM

__tsante-response__ : is emitted when the requested service send its response

__tsante-error__ : fired when the request failed or if the response is not in JSON format

## Example

~~~
<tsante-list url="/api/directory/professionals" pg="1" auto="true" unresolved >
    <div style="height:400px; overflow:auto;">
        <template id="professional" repeat="{{list.items}}">
            <div class="item">
                <div class="name">{{name.family}} {{name.given}}</div>
                <div class="role">{{role}}</div>
            </div>
        </template>
    </div>
</tsante-list>
~~~

## Browser compatibility

 * Chrome 36+
 * Firefox 31+
 * IExplorer 11
 * Safari 7+
 * IOS Safari 7+
 * Android Chrome 36+
 
## Annex
 
### Example of a list

	curl https://physiodom.telecomsante.loc/api/directory

~~~
{
    "nb": 24,
    "pg": 3,
    "offset": 10,
    "items": [
        {
            "name": {
                "family": "Klein",
                "given": "Ellen"
            },
            "gender": "female",
            "telecom": [
                {
                    "system": "email",
                    "value": "ellen.klein@physiodom.loc"
                }
            ],
            "role": "physician",
            "_id": "53fb2763b3371800000d42e1"
        },
        {
            "name": {
                "family": "Reddin",
                "given": "Diana"
            },
            "gender": "female",
            "telecom": [
                {
                    "system": "email",
                    "value": "diana.reddin@physiodom.loc"
                }
            ],
            "role": "physician",
            "_id": "53fb2763b3371800000d42e2"
        },
        {
            "name": {
                "family": "Villars",
                "given": "Claudia"
            },
            "gender": "female",
            "telecom": [
                {
                    "system": "email",
                    "value": "claudia.villars@physiodom.loc"
                }
            ],
            "role": "social worker",
            "_id": "53fb2763b3371800000d42e3"
        },
        {
            "name": {
                "family": "Devereau",
                "given": "Juliet"
            },
            "gender": "female",
            "telecom": [
                {
                    "system": "email",
                    "value": "juliet.devereau@physiodom.loc"
                }
            ],
            "role": "social worker",
            "_id": "53fb2763b3371800000d42e4"
        }
    ]
}
~~~