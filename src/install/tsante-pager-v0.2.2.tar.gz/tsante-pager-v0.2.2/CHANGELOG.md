% CHANGELOG
% Fabrice Le Coz
% October 2014

__v0.2.2__

 - change custom-icon names to avoid overwriting
 
__v0.2.1__

 - Fix Arrows display
 
__v0.2.0 (2014-11-17)__

 - Update polymer to 0.5.x
 - use core-iconset-svg to draw the arrow
 - if number of pages is 1 or 0 the pager is not visible 

| OS            | browser    | status
|---------------|------------|---------
| OSX 10.10     | Chrome 40  | OK
|               | FF 34      | OK
|               | Safari 8   | OK
| Win7          | IE10       | OK
| IOS8.1        | Safari     | OK
| IOS7.1        | Safari     | OK
| Android 4.4.4 | Chrome     | OK 

__v0.1.0 (2014-10-29)__

Update to polymer 0.4.2

tested on 

| OS            | browser    | status
|---------------|------------|---------
| OSX 10.10     | Chrome 40  | OK
|               | FF 34      | OK
|               | Safari 8   | NOK
| Win7          | IE10       | OK
| IOS8.1        | Safari     | NOK
| IOS7.1        | Safari     | OK
| Android 4.4.4 | Chrome     | OK 


> __Nota :__ For Safari 8, this was an [issue of polymer](https://github.com/Polymer/docs/issues/612). Should be fixed on next release.

> __Nota 2 :__ On IOS7.1 the component works but need some enhancements.
