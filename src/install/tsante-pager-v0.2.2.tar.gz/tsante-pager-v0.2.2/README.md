% component : tsante-pager
% Fabrice Le Coz
% Sept 2014

# tsante-pager

## Brief description

This component displays a useful pager to display lists page per page.

![](http://git.telecomsante.com/components/tsante-pager/raw/master/tsante-pager.png)

## Attributes

**nb** : indicate number of items

**offset** : indicate number of items per page

**indx** : set the selected page

## Methods

## Events

**tsante-page** this event is fire when selecting a new page or when clicking on next or previous buttons

in the event detail give the selected page by example : `{ pg: this.indx }`

## Example

~~~
<tsante-pager id="pager" nb="50" offset="1" indx="14"></tsante-pager>
<div id="debug"></div>
<script>
var debug = document.getElementById("debug");
document.getElementById("pager").addEventListener("tsante-page", function(evt) {
	var div = document.createElement("div");
	div.innerHTML = "selected page : "+ evt.detail.pg;
	if(debug.firstChild) {
		debug.insertBefore(div, debug.firstChild);
	} else {
		debug.appendChild(div);
	}
}, false);
</script>
~~~

## Browser compatibility

 * Chrome 36+
 * Firefox 31+
 * IExplorer 11
 * Safari 7+
 * IOS Safari 7+
 * Android Chrome 36+